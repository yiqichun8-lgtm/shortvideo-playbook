---
name: shortvideo-playbook
description: |
  实体生意短视频实操方法路由入口：账号定位、爆款选题、四类脚本、发布前自检，并含 AI 出选题提示词、拍剪执行、自然流引导、拆片法、进阶脚本、IP 问卷与团队矩阵的补充能力卡。
  当用户提到自家生意（门店/工厂/服务商）做抖音/视频号/小红书短视频，询问定位、选题、脚本、自检或拍剪执行时使用。
  仅做投流、后台操作或门店管理等非内容问题时不使用。
metadata:
  cangjie.generated-by: cangjie-tools v2.5.0
  cangjie.variant: router
  cangjie.bundle-id: bdl.shortvideo-playbook.v1
  cangjie.capability-count: 15
  cangjie.entrypoint-count: 8
---
# 实体生意短视频实操方法论体系 — 路由入口（compact pack）

## 触发与不触发

**适用**：与本书能力域相关的咨询与任务（见下方路由表的意图列）。
**不适用**：
- 付费投流（千川/抖加）的操作与出价策略
- 平台后台的具体操作、违规申诉流程
- 菜品研发、成本控制、门店人力管理等非内容经营的专项问题
- 纯线上、无实体交付的业务（本体系默认服务有真实产品或服务的经营者）
- 需要实时数据（当日热点、榜单）的问题——本 Bundle 不联网取数

## 核心原则（常驻速览，概览类问题读到这里即可回答）

1. 经营目标优先：播放量是过程指标，有效咨询、到店、成交与复购才是实体经营者的验收指标
2. 先定位后内容：先确定"用户为什么进店"（进店理由），再决定拍什么——顺序倒了有流量也不变现
3. 先定客户阶段与内容任务：根据对方的购买进度，选择建立理念、增加信任、给出购买理由或发布行动通知
4. 真实证据优先：产品、服务、流程、案例和客户反馈必须可核验，不编造数据、身份或效果
5. 定位的三验收：成交理由充足 + 看起来是真事儿 + 能高频出现 = 水桶型漏斗成立
6. 爆款选题是乘法：一个定位正确的普通选题 × 一个爆款元素（或词根），不是灵感
7. 四类脚本各有固定结构，是填空题不是创作题：聊观点（论据）/ 晒过程（火车节）/ 教知识（四型）/ 讲故事（桥段）
8. 原生感 > 精致感：观众相信"生活中的这个人"，假的东西有技巧有流量也不变现
9. 指标分层：同时观察平均播放时长、完播表现与有效咨询，不用单一点赞数代替经营结果
10. 发布前过七问：不管写完什么，先判定"通过 / 修改后通过 / 暂不发布"

## 能力路由（先读本表，按意图加载 1 张能力卡）

| 用户意图 | 先读 | 补读/备注 |
|---|---|---|
| 我的店/账号该怎么定位；为什么有人看不来客人；我到底有什么可拍的 | references/capabilities/shortvideo-positioning.md | 已晋级为独立 Skill `shortvideo-positioning`（已安装时优先直接使用；本卡仅作背景与细节补充） |
| 帮我出选题；这个标题不够勾人；发什么都没人看想翻新 | references/capabilities/shortvideo-topic-generator.md | 已晋级为独立 Skill `shortvideo-topic-generator`（已安装时优先直接使用；本卡仅作背景与细节补充） |
| 我想发个观点/态度；这事我怎么看写成文案；怎么说才有人共鸣 | references/capabilities/shortvideo-opinion-script.md | 已晋级为独立 Skill `shortvideo-opinion-script`（已安装时优先直接使用；本卡仅作背景与细节补充） |
| 拍个过程视频怎么写；这条太流水账了；开头怎么留人 | references/capabilities/shortvideo-process-script.md | 已晋级为独立 Skill `shortvideo-process-script`（已安装时优先直接使用；本卡仅作背景与细节补充） |
| 教大家一个方法怎么写；干货视频没人看怎么办；想用专业知识涨粉 | references/capabilities/shortvideo-knowledge-script.md | 已晋级为独立 Skill `shortvideo-knowledge-script`（已安装时优先直接使用；本卡仅作背景与细节补充） |
| 讲讲我的创业/开店故事；想夸员工/某个人；这段经历怎么讲才好看 | references/capabilities/shortvideo-story-script.md | 已晋级为独立 Skill `shortvideo-story-script`（已安装时优先直接使用；本卡仅作背景与细节补充） |
| 帮我看看这条行不行；这条为什么没人看；验收一下脚本 | references/capabilities/shortvideo-script-selfcheck.md | 已晋级为独立 Skill `shortvideo-script-selfcheck`（已安装时优先直接使用；本卡仅作背景与细节补充） |
| 给我一段能喂给 AI 的提示词；怎么用 AI 批量出选题 | references/capabilities/shortvideo-ai-topic-prompt.md | references/capabilities/shortvideo-topic-generator.md |
| 手机自拍怎么摆；画面看着别扭怎么改 | references/capabilities/shortvideo-shooting-basics.md | references/capabilities/shortvideo-natural-flow.md、references/capabilities/shortvideo-editing-workflow.md |
| 素材怎么剪；成片看着廉价/累怎么改 | references/capabilities/shortvideo-editing-workflow.md | references/capabilities/shortvideo-shooting-basics.md、references/capabilities/shortvideo-deconstruction.md |
| 要给别人拍/采访怎么引导；老板一开机就僵怎么办 | references/capabilities/shortvideo-natural-flow.md | references/capabilities/shortvideo-ip-intake.md、references/capabilities/shortvideo-shooting-basics.md |
| 拆解同行这条为什么火；分析一下这个爆款 | references/capabilities/shortvideo-deconstruction.md | references/capabilities/shortvideo-topic-generator.md、references/capabilities/shortvideo-editing-workflow.md |
| 想做一条品牌背书的大制作；要不要去原产地溯源 | references/capabilities/shortvideo-advanced-scripts.md | references/capabilities/shortvideo-story-script.md、references/capabilities/shortvideo-process-script.md |
| 接一个新客户先问什么；帮我把这个账号盘一下 | references/capabilities/shortvideo-ip-intake.md | references/capabilities/shortvideo-positioning.md、references/capabilities/shortvideo-story-script.md |
| 要不要开第二个号/给员工开号；内容团队怎么搭 | references/capabilities/shortvideo-matrix-team.md | references/capabilities/shortvideo-positioning.md、references/capabilities/shortvideo-natural-flow.md |

**非能力类查询**：
- 书名/作者/章节/整书概览 → references/overview.md
- 术语解释 → references/glossary.md
- 决策规则速查（不需要详细依据时） → references/cheatsheet.md
- 完整意图与关键词索引（本表未覆盖的意图先查这里） → references/capability-index.md

## 加载规则

- 每次任务先读本文件，再按路由表加载 **1** 张能力卡；任务明确跨域时最多加载 2 张。
- 概览/书名类问题不加载能力卡，用「核心原则」与 overview.md 回答。
- 路由表与 capability-index.md 都无法命中的意图，明确告知超出本书范围，不要硬套。

## 边界与判停

- 用户没有明确的产品/服务，或答不出任何一条进店理由 → 停止出脚本，回到"先把生意的可信点理清楚"
- 用户要求用擦边/虚假/夸大功效的方式获取流量 → 明确拒绝并给出合规替代
- 用户要的是投流、后台操作或实时数据 → 明确告知超出本 Bundle 范围，不要硬套
- 同一需求连续两套方案都不通过七问自检 → 停下来问清楚目标人群，而不是继续换写法
- 不要引用"平台内部规则"，也不要承诺具体数据效果
